import 'package:flutter/material.dart';
import 'package:camera/camera.dart';
import 'image_stream_handler.dart';

class CameraInferenceScreen extends StatefulWidget {
  const CameraInferenceScreen({super.key});

  @override
  State<CameraInferenceScreen> createState() => _CameraInferenceScreenState();
}
  
class _CameraInferenceScreenState extends State<CameraInferenceScreen> {
  late CameraController _controller;
  late ImageStreamHandler _imageStreamHandler;
  bool _isDetecting = false;
  double _currentSpeed = 0.0;
  bool _isInitialized = false;

  @override
  void initState() {
    super.initState();
    _initialize();
  }

  Future<void> _initialize() async {
    final cameras = await availableCameras();
    _controller = CameraController(cameras[0], ResolutionPreset.medium, enableAudio: false);

    _imageStreamHandler = ImageStreamHandler();
    await _imageStreamHandler.loadModel();

    await _controller.initialize();

    _controller.startImageStream((CameraImage image) async {
      if (!_isDetecting) {
        _isDetecting = true;

        try {
          final tensorImage = _imageStreamHandler.processCameraImage(image);
          final result = _imageStreamHandler.runInference(tensorImage);
          final speed = result[0][0] * 100; // 예시 스케일링

          setState(() {
            _currentSpeed = speed;
          });
        } catch (e) {
          debugPrint("Inference error: $e");
        } finally {
          _isDetecting = false;
        }
      }
    });

    setState(() {
      _isInitialized = true;
    });
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: _isInitialized
          ? Stack(
        children: [
          CameraPreview(_controller),
          Positioned(
            top: 60,
            left: 20,
            child: Container(
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(
                color: Colors.black54,
                borderRadius: BorderRadius.circular(8),
              ),
              child: Text(
                'Speed: ${_currentSpeed.toStringAsFixed(2)} km/h',
                style: const TextStyle(color: Colors.white, fontSize: 20),
              ),
            ),
          ),
        ],
      )
          : const Center(child: CircularProgressIndicator()),
    );
  }
}