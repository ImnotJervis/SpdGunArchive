import 'package:camera/camera.dart';
import 'package:tflite_flutter/tflite_flutter.dart';
import 'package:tflite_flutter_helper/tflite_flutter_helper.dart';
import 'package:image/image.dart' as img;

class ImageStreamHandler {
  late Interpreter _interpreter;
  late List<int> _inputShape;
  late List<int> _outputShape;

  Future<void> loadModel() async {
    _interpreter = await Interpreter.fromAsset('model.tflite');
    var inputTensor = _interpreter.getInputTensor(0);
    var outputTensor = _interpreter.getOutputTensor(0);
    _inputShape = inputTensor.shape;
    _outputShape = outputTensor.shape;
  }

  TensorImage processCameraImage(CameraImage image) {
    img.Image convertedImage = convertYUV420ToImage(image);
    TensorImage tensorImage = TensorImage.fromImage(convertedImage);
    tensorImage = ImageProcessorBuilder()
        .add(ResizeOp(_inputShape[1], _inputShape[2], ResizeMethod.NEAREST_NEIGHBOUR))
        .build()
        .process(tensorImage);
    return tensorImage;
  }

  img.Image convertYUV420ToImage(CameraImage image) {
    final int width = image.width;
    final int height = image.height;

    final Plane planeY = image.planes[0];
    final Plane planeU = image.planes[1];
    final Plane planeV = image.planes[2];

    final img.Image imgImage = img.Image(width, height);

    for (int y = 0; y < height; y++) {
      for (int x = 0; x < width; x++) {
        final int uvIndex = (y ~/ 2) * planeU.bytesPerRow + (x ~/ 2) * (planeU.bytesPerPixel ?? 1);
        final int yp = planeY.bytes[y * planeY.bytesPerRow + x];

        final int up = planeU.bytes[uvIndex];
        final int vp = planeV.bytes[uvIndex];

        int r = (yp + vp * 1436 / 1024 - 179).round();
        int g = (yp - up * 46549 / 131072 + 44 - vp * 93604 / 131072 + 91).round();
        int b = (yp + up * 1814 / 1024 - 227).round();

        r = r.clamp(0, 255);
        g = g.clamp(0, 255);
        b = b.clamp(0, 255);

        imgImage.setPixelRgba(x, y, r, g, b);
      }
    }

    return imgImage;
  }

  List<List<double>> runInference(TensorImage inputImage) {
    var input = inputImage.buffer.asFloat32List();
    var output = List.filled(_outputShape.reduce((a, b) => a * b), 0.0).reshape(_outputShape);
    _interpreter.run(input, output);
    return output;
  }
}

extension ListReshape<T> on List<T> {
  List<List<T>> reshape(List<int> shape) {
    if (shape.length != 2) throw ArgumentError('Only 2D reshaping supported');
    final rows = shape[0];
    final cols = shape[1];
    if (this.length != rows * cols) throw ArgumentError('Size mismatch');
    return List.generate(rows, (i) => sublist(i * cols, (i + 1) * cols));
  }
}
