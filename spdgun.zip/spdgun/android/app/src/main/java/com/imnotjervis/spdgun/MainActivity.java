package com.imnotjervis.spdgun;

import io.flutter.embedding.android.FlutterActivity;

public class MainActivity extends FlutterActivity {
}
